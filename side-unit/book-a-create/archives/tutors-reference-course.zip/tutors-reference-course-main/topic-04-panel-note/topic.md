# Panel Note

A Note can be a topic's content
