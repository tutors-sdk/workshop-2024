---
icon:
  type: bi:filetype-pptx
  color: green
---
Lecture 11

Provide a short summary, perhaps supported by a representative image.