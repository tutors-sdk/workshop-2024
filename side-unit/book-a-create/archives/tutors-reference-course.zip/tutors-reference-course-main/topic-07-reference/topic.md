# Reference

Example of all learning resource types
