Lecture 1

A short summary of the talk, no more than two sentences.